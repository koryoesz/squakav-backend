<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 4/24/2020
 * Time: 1:32 PM
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FlightAtsEmergencyRadio extends Model
{

}