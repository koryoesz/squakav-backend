<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 5/21/2020
 * Time: 8:05 AM
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FlightAtsOtherFlightInformation extends Model
{

}