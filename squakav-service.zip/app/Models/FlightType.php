<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 4/23/2020
 * Time: 6:12 PM
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FlightType extends Model
{
        protected $hidden = ['created_at', 'updated_at'];
}