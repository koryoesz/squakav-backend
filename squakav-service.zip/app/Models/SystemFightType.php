<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 5/13/2020
 * Time: 2:02 PM
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SystemFightType extends Model
{

}