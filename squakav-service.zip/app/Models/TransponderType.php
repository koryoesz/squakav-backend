<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 4/24/2020
 * Time: 1:19 PM
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TransponderType extends Model
{
    protected $hidden = ['created_at', 'updated_at'];
}