<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 5/7/2020
 * Time: 3:29 PM
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TransponderTypeProperty extends  Model
{
    protected $hidden = ['created_at', 'updated_at'];
}