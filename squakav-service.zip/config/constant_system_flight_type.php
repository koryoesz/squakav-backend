<?php
return [
    'ats' => [
        'id' => 1,
        'name' => 'ats'
    ],
    'rpl' => [
        'id' => 2,
        'name' => 'rpl'
    ]
];